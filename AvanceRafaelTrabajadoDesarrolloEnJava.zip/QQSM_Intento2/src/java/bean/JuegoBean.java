/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import Modelo.Pregunta;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;

@Named(value = "juegoBean")
@SessionScoped
public class JuegoBean implements Serializable {

    //Atributos
    private int numero;
    private String pregunta;
    private String alternativa1;
    private String alternativa2;
    private String alternativa3;
    private String alternativa4;
    private String respuesta;
    private ArrayList<Pregunta> lista;
    private String respuestaJugador;
    private int cifra;
    
    //Constructor
    public JuegoBean() {
        this.numero = 0;
        this.pregunta = "";
        this.alternativa1 = "";
        this.alternativa2 = "";
        this.alternativa3 = "";
        this.alternativa4 = "";
        this.respuesta = "";
        this.lista = new ArrayList<>();//Lista de preguntas
        this.respuestaJugador = "";
        this.cifra = 0;
    }
    
    //Customers del juego
    public String crearPregunta(){
        for (Pregunta pre : lista) {
            if (!pre.getPregunta().equals(pregunta)) {
                lista.add(pre);
                break;
            }
        }
        return null;
    }
    
    public String jugar(){
        for (Pregunta pre : lista) {
            if (pregunta.isEmpty()&& numero == 0 && alternativa1.isEmpty()&& alternativa2.isEmpty()&& alternativa3.isEmpty() && alternativa4.isEmpty() && respuesta.isEmpty()&& respuestaJugador.isEmpty() && cifra == 0 && !lista.isEmpty())  {
                crearPregunta();
                pre.getAlternativa1(); // pregunta puede funcionar con esto pre.getAlternativa1();
                pre.getAlternativa2();
                pre.getAlternativa3();
                pre.getAlternativa4();
                break;
            }    
            
        }
        
        return nuevoJuego();
    }
    
    public String nuevoJuego(){
       
        
             if(!lista.isEmpty()) {
                 lista.removeAll(lista);
                 
                 
             }
        
        
        return crearPregunta();
    } 

    public String terminarJuego(){
        if(pregunta.isEmpty() || numero == 0 || alternativa1.isEmpty()|| alternativa2.isEmpty()|| alternativa3.isEmpty() || alternativa4.isEmpty() || respuesta.isEmpty()|| respuestaJugador.isEmpty() || cifra == 0 || !lista.isEmpty() ){
            
        
        }
            return null;
    }     

    // Accesadores y Mutadores
    
    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public String getAlternativa1() {
        return alternativa1;
    }

    public void setAlternativa1(String alternativa1) {
        this.alternativa1 = alternativa1;
    }

    public String getAlternativa2() {
        return alternativa2;
    }

    public void setAlternativa2(String alternativa2) {
        this.alternativa2 = alternativa2;
    }

    public String getAlternativa3() {
        return alternativa3;
    }

    public void setAlternativa3(String alternativa3) {
        this.alternativa3 = alternativa3;
    }

    public String getAlternativa4() {
        return alternativa4;
    }

    public void setAlternativa4(String alternativa4) {
        this.alternativa4 = alternativa4;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public ArrayList<Pregunta> getLista() {
        return lista;
    }

    public void setLista(ArrayList<Pregunta> lista) {
        this.lista = lista;
    }

    public String getRespuestaJugador() {
        return respuestaJugador;
    }

    public void setRespuestaJugador(String respuestaJugador) {
        this.respuestaJugador = respuestaJugador;
    }

    public int getCifra() {
        return cifra;
    }

    public void setCifra(int cifra) {
        this.cifra = cifra;
    } 
    
}
